<template>
    <div>
        <div>
            <label>{{title}}</label>
        </div>
        <div>
            <van-field
                    v-model="answer"
                    type="textarea"
                    size="large"
                    placeholder="写下你的回答"
            ></van-field>
        </div>
        <div class="commit">
            <!-- <van-field style="width: 80%;float: left" v-model="answer" placeholder="回答"></van-field> -->
            <van-button style="float: left;width: 100%" @click="commit" type="primary">发表</van-button>
        </div>
    </div>
</template>

<script>
    import mixin from '../mixin/mixin';
    export default {
        name: "answer",
        mixins:[mixin],
        created() {
            let query = this.$route.query;
            console.log(query);
            this.ansid = query.id;
            this.title = query.title;
            this.type = query.type;
        },
        data(){
            return{
                ansid:0,
                title:'',
                answer:'',
                type:''
            }
        },
        methods:{
            commit(){
                let self = this;
                let token = localStorage.getItem('token');
                if(self.type == 'new'){
                    self.$axios.post("http://house-api.zjlaishang.com:9001/new/answer/"+self.ansid,
                        {
                            content:self.answer,
                        },
                        {
                            headers:{
                                token: token
                            }
                        }
                    ).then(function (res) {
                        if(res.data.code == 200){
                            self.$toast(res.data.message);
                            self.answer = '';
                            self.$toast(res.data.msg);
                        }else if(res.data.code == 500){
                            self.$toast(res.data.msg);
                        }else{
                            self.$toast(res.data.msg);
                        }
                    })
                }else if(self.type == 'old'){
                    self.$axios.post("http://house-api.zjlaishang.com:9001/old/answer/"+self.ansid,
                        {
                            content:self.answer,
                        },
                        {
                            headers:{
                                token: token
                            }
                        }
                    ).then(function (res) {
                        if(res.data.code == 200){
                            self.$toast(res.data.message);
                            self.answer = '';
                            self.$toast(res.data.msg);
                        }else if(res.data.code == 500){
                            self.$toast(res.data.msg);
                        }else{
                            self.$toast(res.data.msg);
                        }
                    })
                }
            }
        }
    }
</script>

<style scoped>
    .commit{
        width: 100%;
        height: 50px;
        display: block;
    }
</style>