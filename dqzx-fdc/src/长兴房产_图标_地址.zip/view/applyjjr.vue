<template>
  <div >
       <div class="header">
           <label class="title" v-if="status == 0">申请成为中介</label>
           <label class="desc" v-if="status == 0">成为中介增加上传新楼盘功能，以及二手房 和出租屋发布次数不限</label>
       </div>
       <div class="jiange"></div>
       <van-field
          v-model="tel"
          label="手机号"
          type="tel"
          placeholder="手机号"
          input-align="right"
          v-if="status != -1"
       ></van-field>
       <van-row v-if="status != -1">
           <van-col span="18">
               <van-field
                 v-model="captcha"
                 label="验证码"
                 type="text"
                 placeholder="验证码"
                 input-align="right"
               ></van-field>
               
           </van-col>
           <van-col span="2">
               <button class="newbtn" @click="getCaptcha">获取</button>
           </van-col>
       </van-row>
       <van-field
          v-model="name"
          label="真实姓名"
          type="text"
          required
          placeholder="真实姓名"
          input-align="right"
          :formatter="formatter"
          v-if="status != -1"
       ></van-field>
       <van-field
          v-model="fanwei"
          label="业务范围"
          type="text"
          required
          placeholder="业务范围"
          input-align="right"
          readonly
          clickable
          v-if="status != -1"
          @click="fanweiselect"
       ></van-field>
       <el-dialog :visible.sync="showdialog" title="业务范围">
           <van-row>
               <ul class="zhuangxiu" style="width: 100%;border-bottom: 1px solid #ECECEC">
                   <ul v-for="(item,index) in options1" :key="index">
                       <li @click="clickarea(item.value)" :class="{active:area == item.value}">{{item.value}}</li>
                   </ul>
               </ul>
           </van-row>
       </el-dialog>
       <div class="jiange"></div>
       <van-field
          v-model="companyName"
          label="公司名称"
          type="text"
          placeholder="公司名称"
          v-if="status != -1"
          input-align="right"
       ></van-field>
       <van-field name="uploader" label="公司营业执照" v-if="status != -1">
        </van-field>
        <van-row v-if="status != -1">
            <van-uploader v-model="uploader" max-count="1" accept="image/*" result-type="dataUrl"/>
        </van-row>
        <button class="sub" v-if="status != -1" @click="submit">提交信息</button>
        <button class="sub" v-if="status == -1" @click="submit">认证手机号</button>
  </div>
</template>

<script>
import 'element-ui/lib/theme-chalk/index.css';
import mixin from '../mixin/mixin';
export default {
  name: 'app',
//   mixins:[mixin],
  components: {

  },
  data(){
      return{
          tel:'',
          captcha:'',
          name:'',
          fanwei:'',
          showdialog:false,
          options1:[],
          area:'',
          companyName:'',
          uploader:[],
          filess:'',
          status:null
      }
  },
  created(){
      let query = this.$route.query;
      this.status = query.status0;
      this.tel = query.tel;
      this.getOptions();
  },
  methods:{
      getOptions(){
          let self = this;
          let token = localStorage.getItem("token");
          this.$axios.get("http://house-api.zjlaishang.com:9001/type/area",{
              headers:{
                  token:token
              }
          }).then(function(res){
              if(res.data.code == 200){
                  res.data.data.forEach(item=>{
                      self.options1.push(item);
                  })
                // self.options1 = res.data.data;
                  console.log(self.options1);
              }else{
                  self.$toast(res.data.msg);
              }
          })
      },
      getCaptcha(){
          let self = this;
          let token = localStorage.getItem("token");
          console.log("captcha");
          let formdata = new FormData();
          formdata.append("phone",self.tel);
          self.$axios.post("http://house-api.zjlaishang.com:9001/sendSms/ali",formdata,{
              
          }).then(function(res){
              if(res.code == 200){
                  self.$toast(res.data,msg);
              }else{
                  self.$toast(res.data.msg);
              }
          })
      },
      submit(){
          if(this.status != -1){
              let phone = this.tel;
              let captcha = this.captcha;
              this.trans(this.uploader);
              let fanwei = this.fanwei;
              let area = parseInt(this.area);
              let companyName = this.companyName;
              let name = this.name;
             if(phone == ''||fanwei == ''||area == 0||companyName == ''||name == ''){
                 this.$toast("有元素未填");
                  return;
                }
               let formdata = new FormData();
               formdata.append("areaId",area);
               formdata.append("name",name);
               formdata.append("phone",Number(phone));
               formdata.append("company",companyName);
               formdata.append("img",this.filess);
               let token = localStorage.getItem("token");
               let self = this;
               self.$axios.get("http://house-api.zjlaishang.com:9001/broker",formdata,{
                   headers:{
                       token:token
                   }
               }).then(function(res){
                   if(res.data.code == 200){
                       self.$toast(res.data.msg);
                   }else{
                       self.$toast(res.data.msg);
                   }
               })
          }else if(this.status == -1){
              let self = this;
              let formdata = new FormData();
              formdata.append('phone',Number(this.tel));
              formdata.append('smsCode',this.captcha);
          }
      },
      clickarea(index){
          if(this.area != index){
              this.area = index;
          }else{
              this.area = '';
          }
          this.options1.forEach(item=>{
              if(item.value == index){
                  this.fanwei = item.text;
              }
          })
      },
      trans(uploader){
          this.filess = this.uploader[0].content;
          console.log(this.filess);
      },
      formatter(value){
          return value.replace(/[^\u4E00-\u9FA5]/g,'')
      },
      fanweiselect(){
          this.showdialog = true;
      }
  }
}
</script>

<style>
    .van-field__label{
        -webkit-box-flex: 0;
        -webkit-flex: none;
        flex: none;
        box-sizing: border-box;
        width: 6.2em;
        margin-right: 12px;
        color: #2A333C;
        font-size: 19px;
        font-weight:bold;
        text-align: left;
        word-wrap: break-word;
    }
    .header{
        width: 100%;
        display: inline-flex;
        flex-direction: column;
    }
    .header .title{
        margin-left: 23px;
        margin-top: 47px;
        font-size: 23px;
        color: #000;
    }
    .header .desc{
        margin-left: 23px;
        margin-top: 21px;
        margin-bottom: 18px;
        font-size: 14px;
        color: #8D8D8D;
        width: 272px;
    }

    .jiange{
        background: #F1F3F7;
        height: 17px;
        width: 100%;
    }

    .newbtn{
        width: 79px;
        height: 34px;
        border-radius: 6px;
        border: 1px solid rgba(86, 124, 243, 1);
        background-color: rgba(247,249,249,1);
        font-size:18px;
        color:rgba(78,117,238,1);
        line-height: 8px;
    }

    .zhuangxiu{
        width: 90%;
    }

    .zhuangxiu li{
        float: left;
        text-align: center;
        line-height: 36px;
        cursor: pointer;
        width: 70px;
        height: 36px;
        background-color: #D8D8D8;
        font-size: 14px;
        color: #000;
        border-radius: 4px;
        margin-top: 10.1px;
        margin-bottom: 6.6px;
    }

    .zhuangxiu .active{
        background-color: #FCF6EF;
        color: #EC613E;
    }
    .sub{
        width: 100%;
        height:50px;
        background:rgba(59,135,246,1);
        border:1px solid rgba(54, 122, 221);
        font-size:20px;
        font-family:PingFang SC;
        font-weight:bold;
        color:rgba(255,255,255,1);
    }
    /*#app{*/
    /*    background: #F7F9FE;*/
    /*}*/
</style>